import peoples from "../db/people.json";
import { IPeople } from "interface/IPeople";
import fs from "fs";
import path from "path";
import { IHomeworld } from "interface/IHomeworld";

class BackendModel {

    constructor() {
      // TODO document why this constructor is empty
    }

    public getPeopleByID = (id: number) => peoples[--id];

    public getHomeworldByID = (id: number) => {
        let data = fs.readFileSync(path.join(__dirname, "../db/homeworld.json"),'utf8');
        let jsonObject = JSON.parse(data)
        let result = (jsonObject[id-1] as IHomeworld).name
        console.log(jsonObject[id-1])
        return result
    }

    public getfilmsByID = (id: number) => {
        let data = fs.readFileSync(path.join(__dirname, "../db/film.json"),'utf8');
        console.log(data)
        let jsonObject = JSON.parse(data)
        let result = jsonObject[id-1].title
        console.log(jsonObject[id-1])
        return result
    }

    public getspeciesByID = (id: number) => {
        let data = fs.readFileSync(path.join(__dirname, "../db/species.json"),'utf8');
        console.log(data)
        let jsonObject = JSON.parse(data)
        let result = jsonObject[id-1].name
        console.log(jsonObject[id-1])
        return result
    }

    public getvehiclesByID = (id: number) => {
        let data = fs.readFileSync(path.join(__dirname, "../db/vehiculos.json"),'utf8');
        console.log(data)
        let jsonObject = JSON.parse(data)
        let result = jsonObject[id-1].name
        console.log(jsonObject[id-1])
        return result
    }

    public getstartshipsByID = (id: number) => {
        let data = fs.readFileSync(path.join(__dirname, "../db/starships.json"),'utf8');
        console.log(data)
        let jsonObject = JSON.parse(data)
        let result = jsonObject[id-1].name
        console.log(jsonObject[id-1])
        return result
    }

    public insertPeople = (people: IPeople): boolean => {
        console.log(path.join(__dirname, 'db'));
        let data = fs.readFileSync('dist/db/people.json', 'utf8');
        let peopleData: IPeople[] = JSON.parse(data);
        peopleData.push(people);
        data = JSON.stringify(peopleData);
        fs.writeFile('dist/db/people.json', data, (err) => {
            if (err) throw err;
            return false;
        });
        return true;
    }

    public insertHomewordl = (homeworld: IHomeworld): boolean => {
        console.log(path.join(__dirname, 'db'));
        let data = fs.readFileSync('dist/db/homeworld.json', 'utf8');
        let homeworldData: IHomeworld[] = JSON.parse(data);
        homeworldData.push(homeworld);
        data = JSON.stringify(homeworldData);
        fs.writeFile('dist/db/homeworld.json', data, (err) => {
            if (err) throw err;
            return false;
        });
        return true;
    }

    public updatePeople = (people: IPeople): boolean => {
        console.log('UPDATE');
        return true;
    }

    public deletePeople = (id: number): boolean => {
        console.log('DELETE');
        return true;
    }
}

export default BackendModel;