import { Request, Response } from "express";
import BackendModel from "../model/BackendModel";

class BackendController {

    private model: BackendModel;

    constructor() {
        this.model = new BackendModel();
    }

    public index = (req: Request, res: Response) => res.json({ 'error': 0, 'msg': 'API: node-express-ts' });
    
    public getPeople = (req: Request, res: Response) => {
        const { id } = req.params;
        const people = this.model.getPeopleByID(parseInt(id));
        if (people) {
            return res.send(people);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }

    public getHomeworld = (req: Request, res: Response) => {
        const { id } = req.params;
        const homeworld = this.model.getHomeworldByID(parseInt(id));
        if (homeworld) {
            return res.send(homeworld);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }
    public getfilms = (req: Request, res: Response) => {
        const { id } = req.params;
        const films = this.model.getfilmsByID(parseInt(id));
        if (films) {
            return res.send(films);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }

    public getspecies = (req: Request, res: Response) => {
        const { id } = req.params;
        const films = this.model.getspeciesByID(parseInt(id));
        if (films) {
            return res.send(films);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }

    public getvehicles = (req: Request, res: Response) => {
        const { id } = req.params;
        const films = this.model.getvehiclesByID(parseInt(id));
        if (films) {
            return res.send(films);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }

    public getstartships = (req: Request, res: Response) => {
        const { id } = req.params;
        const films = this.model.getstartshipsByID(parseInt(id));
        if (films) {
            return res.send(films);
        }
        return res.json({ 'error': 1, 'msg': 'API: id no found' });
    }

    public insertPeople = (req: Request, res: Response) => { 
        this.model.insertPeople(req.body);
        return res.json({ 'error': 0, 'msg': 'API: insert' });
    }

    public insertHomeworld = (req: Request, res: Response) => { 
        this.model.insertHomewordl(req.body);
        return res.json({ 'error': 0, 'msg': 'API: insert' });
    }

    public updatePeople = (req: Request, res: Response) => { 
        this.model.updatePeople(req.body);
        return res.json({ 'error': 0, 'msg': 'API: update' });
    }

    public deletePeople = (req: Request, res: Response) => {
        const { id } = req.body;
        this.model.deletePeople(parseInt(id));
        return res.json({ 'error': 0, 'msg': `API: delete id: ${id}` });
     }

}

export default BackendController;