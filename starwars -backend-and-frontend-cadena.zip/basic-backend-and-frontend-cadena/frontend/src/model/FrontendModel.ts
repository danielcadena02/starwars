import { IPeople } from "src/interface/IPeople";
import { IHomeworld } from '../interface/IHomeworld';

export class FrontendModel {

    public url: string;
    public urls:string

    constructor () {
        this.url = 'https://swapi.dev/api/'; 
        this.urls = 'http://localhost:1802/api/'; 
    }

    public getPeopleByID(id: number, fn: Function): void {
        console.log('paso')
        this.http(`${this.url}people/${id}`, 'get', fn);
    }

    public http = async (url: string, method: string, fn: Function) => {
        const response = await fetch(url, {method: method});
        const data:IPeople = await response.json();
        console.log(data.homeworld)
        //let [ss,home] = data.homeworld.split('https://swapi.dev/api')
        var [homeworld] = await Promise.all([
            //get Planets
            this.fetch(data.homeworld),
            //add films
            this.modificarArreglos(data.films,'title'),
            //add species
            this.modificarArreglos(data.species,'name'),
            //add vehicles
            this.modificarArreglos(data.vehicles,'name'),
            //add starships
            this.modificarArreglos(data.starships,'name')
        ]);
        
        console.log(data);
        //add planet name
        data.homeworld = (homeworld as IHomeworld).name
        
        //console.log(data)
        fn(data);
    }
    public modificarArreglos = async(info:string[],value:string):Promise<void>=>{
        const jsons = await Promise.all(info.map(async url => {
            //const [ss,home] = url.split('https://swapi.dev/api')
            const resp = await fetch(url);
            const data = await resp.json();
             //console.log(resp)
            return data;
          }));
          console.log(jsons)
          for(let i = 0; i < jsons.length; i++) {
            console.log(jsons[i][value])
            info[i] = jsons[i][value]
          }
     }
     public fetch = async (url:string): Promise<unknown> => {
        const response = await fetch(url);
        const data = await response.json();
        //console.log(data)
        return data
     }
   
}
