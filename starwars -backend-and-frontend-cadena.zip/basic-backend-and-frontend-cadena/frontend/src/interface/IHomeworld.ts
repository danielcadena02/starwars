export interface IHomeworld {
    name: string;

}