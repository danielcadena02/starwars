var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
export class FrontendModel {
    constructor() {
        this.http = (url, method, fn) => __awaiter(this, void 0, void 0, function* () {
            const response = yield fetch(url, { method: method });
            const data = yield response.json();
            console.log(data.homeworld);
            //let [ss,home] = data.homeworld.split('https://swapi.dev/api')
            var [homeworld] = yield Promise.all([
                //get Planets
                this.fetch(data.homeworld),
                //add films
                this.modificarArreglos(data.films, 'title'),
                //add species
                this.modificarArreglos(data.species, 'name'),
                //add vehicles
                this.modificarArreglos(data.vehicles, 'name'),
                //add starships
                this.modificarArreglos(data.starships, 'name')
            ]);
            console.log(data);
            //add planet name
            data.homeworld = homeworld.name;
            //console.log(data)
            fn(data);
        });
        this.modificarArreglos = (info, value) => __awaiter(this, void 0, void 0, function* () {
            const jsons = yield Promise.all(info.map((url) => __awaiter(this, void 0, void 0, function* () {
                //const [ss,home] = url.split('https://swapi.dev/api')
                const resp = yield fetch(url);
                const data = yield resp.json();
                //console.log(resp)
                return data;
            })));
            console.log(jsons);
            for (let i = 0; i < jsons.length; i++) {
                console.log(jsons[i][value]);
                info[i] = jsons[i][value];
            }
        });
        this.fetch = (url) => __awaiter(this, void 0, void 0, function* () {
            const response = yield fetch(url);
            const data = yield response.json();
            //console.log(data)
            return data;
        });
        this.url = 'https://swapi.dev/api/';
        this.urls = 'http://localhost:1802/api/';
    }
    getPeopleByID(id, fn) {
        console.log('paso');
        this.http(`${this.url}people/${id}`, 'get', fn);
    }
}
