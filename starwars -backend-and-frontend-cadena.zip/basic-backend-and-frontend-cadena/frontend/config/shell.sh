npm i typescript
npx tsc --init
npx tsc -w